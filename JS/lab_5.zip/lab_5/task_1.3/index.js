function computePower(num, exponent) {
  return Math.pow(num, exponent);
}

var output = computePower(2, 3);
console.log(output); 