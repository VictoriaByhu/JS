function computeSquareRoot(num) {
  return Math.sqrt(num);
}

var output = computeSquareRoot(9);
console.log(output);
