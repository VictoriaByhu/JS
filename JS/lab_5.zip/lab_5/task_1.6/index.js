function joinArrays(arr1, arr2) {
  return arr1.concat(arr2);
}

var output = joinArrays([1, 2], [3, 4]);
console.log(output); 