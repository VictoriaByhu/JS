function computeAreaOfACircle(radius) {
  return Math.PI * Math.pow(radius, 2);
}

var output = computeAreaOfACircle(4);
console.log(output);
