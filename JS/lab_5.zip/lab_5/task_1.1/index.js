function computeAreaOfARectangle(length, width) {
  return length * width;
}

var output = computeAreaOfARectangle(4, 8);
console.log(output);
